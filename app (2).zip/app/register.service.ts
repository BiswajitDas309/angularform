import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { Student, Teacher } from "./model";

@Injectable({
    providedIn: 'root'
})
export class RegistrationService {
     studentSubject: Subject<Student> = new Subject<Student>();
     teacherSubject: Subject<Teacher> = new Subject<Teacher>();

     getstudentData(data:any){
        this.studentSubject.next(data)
     }
     getteacherData(item:any){
        this.teacherSubject.next(item)
     }

}