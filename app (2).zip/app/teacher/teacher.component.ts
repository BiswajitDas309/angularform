import { Component } from '@angular/core';
import { Teacher, TeacherCount, Teacherdata, teacherDetails } from '../model';
import { Subscription } from 'rxjs';
import { RegistrationService } from '../register.service';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent {

  teacherdata: Array<Teacher> = new Array<Teacher>();
  teacher: Array<Teacherdata> = new Array<Teacherdata>();
  teacherDetailsList: Array<teacherDetails> = new Array<teacherDetails>();
  count: number = 0;
  title: string = '';
  subjectName:string='';
  Subscription: Subscription = new Subscription();
  constructor(private _registrationservice: RegistrationService) { }
  ngOnInit() {
      this._registrationservice.teacherSubject.subscribe(rec => {
          this.teacherdata.push(rec);
          this.getData();
      })
  };
  getData() {
      this.teacherdata.forEach((item) => {
          let subdata = item.subject.join('').toString();
          if (this.teacher.filter((x) => x.subject == subdata).length == 0) {
              let obj: Teacherdata = new Teacherdata();
              this.count = this.count + 1;
              obj.id = this.count;
              obj.subject = subdata;
              this.teacher.push(obj);
          };
      });
      this.teacher.forEach((item) => {
          let teacher = this.teacherdata.filter((x) => x.subject.toString() == item.subject);
          let teachdata: Array<TeacherCount> = new Array<TeacherCount>();
          teacher.forEach((child) => {
              let sub = child.subject.toString();
              if (teachdata.filter((x) => x.subject == sub && x.id == child.id).length == 0) {
                  let obj: TeacherCount = new TeacherCount();
                  obj.id = child.id;
                  obj.subject = sub;
                  teachdata.push(obj);
                  item.teacherCount = teachdata.length;
              }
          })
      })
  }
  teacherdetailes(val: string) {
    this.subjectName = val;
    let result = this.teacherdata.filter(x => x.subject.toString() == val);
    this.teacherDetailsList = result;
  };
}
