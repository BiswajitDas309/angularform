import { Component } from '@angular/core';
import { Registeration, Student, Subject, Teacher, Teachersub } from '../model';
import { RegistrationService } from '../register.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {


  registrationform: Registeration = new Registeration();
  student: Student = new Student();
  teacher: Teacher = new Teacher();
  subjectdata: Array<Subject> = new Array<Subject>();
  // subject: Subject = new Subject();

  subTeacher: Teachersub = new Teachersub();
  TeachersubList: Teachersub[] = [];

  Key: number = 0;
  hideClass: boolean = false;
  hideSubject: boolean = false;

  constructor(private _registrationservice: RegistrationService) { }

  ngOnInit() {
    this.getSubject();
  }

  getSubject() {
    this.subjectdata = [
      { id: 1, name: "Hindi", isSelected: false },
      { id: 2, name: "English", isSelected: false },
      { id: 3, name: "Telgu", isSelected: false },
      { id: 4, name: "Maths", isSelected: false },
      { id: 5, name: "Science", isSelected: false },
      { id: 6, name: "Social", isSelected: false }
    ];

  }
  onChange(event: any) {
    if (event.target.value == 'student') {
      this.hideClass = true;
      this.hideSubject = false;
    } else {
      this.hideSubject = true;
      this.hideClass = false;
    };
  };
  saveClick() {
    if (this.registrationform.name.length < 3) {
      alert("Name should be 3 characters");
    } else if (this.registrationform.name.length > 25) {
      alert("maximum 25 characters are allowed");
    } else if (this.registrationform.regType == "student") {
      this.Key = this.Key + 1;
      this.student.id = this.Key;
      this.student.gender = this.registrationform.gender;
      this.student.name = this.registrationform.name;
      this.student.class = this.registrationform.class;
      this._registrationservice.getstudentData(this.student);
      this.student = new Student();
      this.registrationform = new Registeration();

    }
    else if (this.registrationform.regType == "teacher") {
      if (this.subjectdata.find((x) => x.isSelected == true)) {
        this.subTeacher.subjectId = this.subjectdata.filter((x) => x.isSelected == true).map(x => x.id).toString();
        this.subTeacher.subjectName = this.subjectdata.filter(x => x.isSelected == true).map(x => x.name).toString();
        this.Key = this.Key + 1;
        this.teacher.id = this.Key;
        this.teacher.name = this.registrationform.name;
        this.teacher.gender = this.registrationform.gender;
        this.teacher.subject.push(this.subTeacher.subjectName);
        this._registrationservice.getteacherData(this.teacher);
        this.teacher = new Teacher();
        this.registrationform = new Registeration();
        this.subjectdata.forEach((item) => {
          item.isSelected = false;
        })
      } else {
        alert("please select subjects");
      }
    };

  };


}
