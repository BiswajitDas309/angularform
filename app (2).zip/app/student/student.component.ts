import { Component } from '@angular/core';
import { Student, StudentDetail, studentCount, studentD } from '../model';
import { Subscription } from 'rxjs';
import { RegistrationService } from '../register.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {

  studentdata: Array<Student> = new Array<Student>();
  studentBo: Array<studentD> = new Array<studentD>();
  stuDetailsList: Array<StudentDetail> = new Array<StudentDetail>();
  count: number = 0;
  className:string = '';
  Subscription: Subscription = new Subscription();

  constructor(private _regservice: RegistrationService) { }

  ngOnInit() {
      this._regservice.studentSubject.subscribe(rec => {
          this.studentdata.push(rec);
          console.log(this.studentdata);
          this.getstudentData();
      })
  };
  getstudentData() {
      this.studentdata.forEach((data) => {
          let sub = data.class.toString();
          if (this.studentBo.filter((x) => x.class == sub).length == 0) {
              let obj: studentD = new studentD();
              this.count = this.count + 1;
              obj.id = this.count;
              obj.class = sub;
              this.studentBo.push(obj);
          }
      });
      this.studentBo.forEach((rec) => {
          let student = this.studentdata.filter((x) => x.class.toString() == rec.class);
          let studata: Array<studentCount> = new Array<studentCount>();
          student.forEach((data) => {
              let cls = data.class.toString();
              if (studata.filter((x) => x.class == cls && x.id == data.id).length == 0) {
                  let obj: studentCount = new studentCount();
                  obj.id = data.id;
                  obj.class = cls;
                  studata.push(obj);
                  rec.studentCount = studata.length;
              }
          })
      })
  }

  studentdetailes(val: string) {
    this.className = val;
    let result = this.studentdata.filter(x => x.class.toString() == val);
    this.stuDetailsList = result
   
  };

  


}
