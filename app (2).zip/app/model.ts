export class Registeration {
    regType: string = "";
    name: string = '';
    gender: string = '';
    class: string = '';
    subject: Array<string> = [];
}

export class Student {
    id: number = 0;
    name: string = '';
    gender: string = '';
    class: string = '';
}

export class Teacher {
    id: number = 0;
    name: string = '';
    gender: string = '';
    subject: Array<string> = [];
}

export class Teachersub {
    id: number = 0;
    name: string = "";
    gender: string = "";
    subjectId: string = "";
    subjectName: string = "";
}

export class Subject {
    id: number = 0;
    name: string = "";
    isSelected !: boolean;
}

export class Teacherdata {
    id: number = 0;
    subject: string = '';
    teacherCount: number = 0;
}

export class TeacherCount {
    id: number = 0;
    subject: string = '';
}

export class teacherDetails {
    name: string = "";
    gender: string = "";
    subject: Array<string> = [];
}


export class studentD {
    id: number = 0;
    class: string = '';
    studentCount: number = 0;
}
export class studentCount {
    id: number = 0;
    class: string = '';
}
export class StudentDetail {
    name: string = "";
    gender: string = "";
    class: string = '';
}